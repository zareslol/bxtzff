const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const API_BASE = 'https://api-gateway.umbrellapag.com/api';
const API_KEY = '2535600b-aa49-49c0-9e40-8c7b668bae38';

const HEADERS = {
  'x-api-key': API_KEY,
  'User-Agent': 'UMBRELLAB2B/1.0',
  'Content-Type': 'application/json'
};

// GET produtos
app.get('/proxy/products', async (req, res) => {
  try {
    const r = await fetch(`${API_BASE}/user/products`, { headers: HEADERS });
    const data = await r.json();
    console.log('[PRODUCTS]', JSON.stringify(data));
    res.json(data);
  } catch (e) {
    console.error('[PRODUCTS ERROR]', e.message);
    res.status(500).json({ error: e.message });
  }
});

// POST criar produto
app.post('/proxy/create-product', async (req, res) => {
  try {
    const r = await fetch(`${API_BASE}/user/products`, {
      method: 'POST',
      headers: HEADERS,
      body: JSON.stringify(req.body)
    });
    const data = await r.json();
    console.log('[CREATE PRODUCT]', JSON.stringify(data));
    res.json(data);
  } catch (e) {
    console.error('[CREATE PRODUCT ERROR]', e.message);
    res.status(500).json({ error: e.message });
  }
});

// POST criar order
app.post('/proxy/create-order/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log('[CREATE ORDER] uniqueProductLinkId:', id);
    const r = await fetch(`${API_BASE}/public/checkout/create-order/${id}`, {
      method: 'POST',
      headers: HEADERS
    });
    const data = await r.json();
    console.log('[CREATE ORDER RESP]', JSON.stringify(data));
    res.json(data);
  } catch (e) {
    console.error('[CREATE ORDER ERROR]', e.message);
    res.status(500).json({ error: e.message });
  }
});

// POST criar pagamento
app.post('/proxy/payment/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log('[PAYMENT] orderId:', id, 'body:', JSON.stringify(req.body));
    const r = await fetch(`${API_BASE}/public/checkout/payment/${id}`, {
      method: 'POST',
      headers: HEADERS,
      body: JSON.stringify(req.body)
    });
    const data = await r.json();
    console.log('[PAYMENT RESP]', JSON.stringify(data));
    res.json(data);
  } catch (e) {
    console.error('[PAYMENT ERROR]', e.message);
    res.status(500).json({ error: e.message });
  }
});

// GET status pagamento
app.get('/proxy/payment-status/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const r = await fetch(`${API_BASE}/public/checkout/find-info-order/${id}`, { headers: HEADERS });
    const data = await r.json();
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Serve index.html para qualquer rota
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Server rodando na porta ${PORT}`));
